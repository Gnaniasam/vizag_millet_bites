<?php
// set_admin_password helper
// Copy full code from canvas doc.
