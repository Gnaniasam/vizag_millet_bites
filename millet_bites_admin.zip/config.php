<?php
// config.php
// Copy full code from canvas doc.
