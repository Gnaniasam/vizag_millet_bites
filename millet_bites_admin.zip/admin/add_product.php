<?php
// add_product.php
// Copy full code from canvas doc.
