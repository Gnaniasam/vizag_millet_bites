<?php
// products.php
// Copy full code from canvas doc.
