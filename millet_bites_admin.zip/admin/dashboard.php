<?php
// dashboard.php
// Copy full code from canvas doc.
