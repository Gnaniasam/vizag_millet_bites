<?php
// get_products.php
// Copy full code from canvas doc.
